import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Library } from 'lucide-react';
import { LibroCard } from './components/LibroCard';
import { LibroDetalle } from './components/LibroDetalle';
import { Filtros } from './components/Filtros';
import { Buscador } from './components/Buscador';
import { MensajeNoDisponibles } from './components/MensajeNoDisponibles';
import { obtenerLibros } from './services/api';
import { Libro, FiltroTipo } from './types';

function App() {
  const [libros, setLibros] = useState<Libro[]>([]);
  const [filtro, setFiltro] = useState<FiltroTipo>('todos');
  const [busqueda, setBusqueda] = useState('');
  const [cargando, setCargando] = useState(true);
  const [libroSeleccionado, setLibroSeleccionado] = useState<Libro | null>(null);

  useEffect(() => {
    const cargarLibros = async () => {
      try {
        const datos = await obtenerLibros();
        setLibros(datos);
      } catch (error) {
        console.error('Error al cargar los libros:', error);
      } finally {
        setCargando(false);
      }
    };

    cargarLibros();
  }, []);

  const librosFiltrados = libros.filter((libro) => {
    const cumpleFiltro = 
      filtro === 'todos' ? true :
      filtro === 'disponibles' ? libro.disponibilidad :
      !libro.disponibilidad;

    const cumpleBusqueda = libro.titulo
      .toLowerCase()
      .includes(busqueda.toLowerCase());

    return cumpleFiltro && cumpleBusqueda;
  });

  const todosDisponibles = libros.every(libro => libro.disponibilidad);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-4 mb-4">
            <Library className="w-12 h-12 text-indigo-600" />
            <h1 className="text-4xl font-bold text-gray-900">Biblioteca Digital</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Explora nuestra colección de libros digitales
          </p>
        </motion.div>

        <Buscador busqueda={busqueda} setBusqueda={setBusqueda} />
        <Filtros filtroActual={filtro} cambiarFiltro={setFiltro} />

        {cargando ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-600 border-t-transparent"></div>
          </div>
        ) : (
          <>
            {filtro === 'nodisponibles' && todosDisponibles ? (
              <MensajeNoDisponibles />
            ) : (
              <motion.div
                layout
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                <AnimatePresence>
                  {librosFiltrados.map((libro, index) => (
                    <motion.div
                      key={`${libro.titulo}-${index}`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <LibroCard
                        libro={libro}
                        onClick={() => setLibroSeleccionado(libro)}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </>
        )}
      </div>

      <LibroDetalle
        libro={libroSeleccionado}
        onClose={() => setLibroSeleccionado(null)}
      />
    </div>
  );
}

export default App;