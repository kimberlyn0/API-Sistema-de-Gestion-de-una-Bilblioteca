import { motion } from 'framer-motion';
import { Book } from 'lucide-react';
import { Libro } from '../types';
import { obtenerImagenLibro } from '../utils/bookImages';

interface LibroCardProps {
  libro: Libro;
  onClick: () => void;
}

export const LibroCard = ({ libro, onClick }: LibroCardProps) => {
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      className="bg-white rounded-lg shadow-lg overflow-hidden cursor-pointer"
      onClick={onClick}
    >
      <motion.img
        src={obtenerImagenLibro(libro.titulo)}
        alt={libro.titulo}
        className="w-full h-48 object-cover"
        whileHover={{ scale: 1.05 }}
        transition={{ type: "spring", stiffness: 300 }}
      />
      
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{libro.titulo}</h3>
        <div className="space-y-1">
          <p className="text-gray-600 text-sm">
            <span className="font-medium">Autor:</span> {libro.autor.nombre}
          </p>
          <p className="text-gray-600 text-sm">
            <span className="font-medium">Año:</span> {libro.anioPublicacion}
          </p>
          <span
            className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
              libro.disponibilidad
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
            }`}
          >
            {libro.disponibilidad ? 'Disponible' : 'No disponible'}
          </span>
        </div>
      </div>
    </motion.div>
  );
};