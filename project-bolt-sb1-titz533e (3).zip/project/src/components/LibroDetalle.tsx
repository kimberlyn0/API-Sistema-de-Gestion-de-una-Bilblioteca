import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Libro, Comentario } from '../types';
import { obtenerImagenLibro } from '../utils/bookImages';
import { SeccionComentarios } from './SeccionComentarios';
import { useState } from 'react';

interface LibroDetalleProps {
  libro: Libro | null;
  onClose: () => void;
}

export const LibroDetalle = ({ libro, onClose }: LibroDetalleProps) => {
  const [comentarios, setComentarios] = useState<Comentario[]>(libro?.comentarios || []);

  if (!libro) return null;

  const agregarComentario = (texto: string) => {
    const nuevoComentario: Comentario = {
      id: Date.now().toString(),
      texto,
      autor: 'Usuario',
      fecha: new Date().toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
    };
    setComentarios([...comentarios, nuevoComentario]);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-xl p-6 max-w-2xl w-full shadow-2xl relative my-8"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="grid md:grid-cols-2 gap-6">
            <motion.img
              src={obtenerImagenLibro(libro.titulo)}
              alt={libro.titulo}
              className="w-full h-64 object-cover rounded-lg shadow-md"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            />
            
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-gray-800">{libro.titulo}</h2>
              
              <div className="space-y-2">
                <p className="text-gray-700">
                  <span className="font-semibold">Autor:</span> {libro.autor.nombre}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Nacionalidad:</span> {libro.autor.nacionalidad}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Año de publicación:</span> {libro.anioPublicacion}
                </p>
                <span
                  className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                    libro.disponibilidad
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {libro.disponibilidad ? 'Disponible' : 'No disponible'}
                </span>
              </div>
            </div>
          </div>

          <SeccionComentarios
            comentarios={comentarios}
            onAgregarComentario={agregarComentario}
          />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};