import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send } from 'lucide-react';
import { Comentario } from '../types';

interface SeccionComentariosProps {
  comentarios: Comentario[];
  onAgregarComentario: (texto: string) => void;
}

export const SeccionComentarios = ({ comentarios, onAgregarComentario }: SeccionComentariosProps) => {
  const [nuevoComentario, setNuevoComentario] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nuevoComentario.trim()) {
      onAgregarComentario(nuevoComentario);
      setNuevoComentario('');
    }
  };

  return (
    <div className="mt-6 border-t pt-6">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-5 h-5 text-indigo-600" />
        <h3 className="text-lg font-semibold">Comentarios</h3>
      </div>

      <form onSubmit={handleSubmit} className="mb-6">
        <div className="flex gap-2">
          <input
            type="text"
            value={nuevoComentario}
            onChange={(e) => setNuevoComentario(e.target.value)}
            placeholder="Escribe tu comentario..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="submit"
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg flex items-center gap-2 hover:bg-indigo-700 transition-colors"
          >
            <Send className="w-4 h-4" />
            Enviar
          </motion.button>
        </div>
      </form>

      <AnimatePresence>
        <div className="space-y-4">
          {comentarios.map((comentario, index) => (
            <motion.div
              key={comentario.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 p-4 rounded-lg"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-medium text-gray-800">{comentario.autor}</span>
                <span className="text-sm text-gray-500">{comentario.fecha}</span>
              </div>
              <p className="text-gray-700">{comentario.texto}</p>
            </motion.div>
          ))}
        </div>
      </AnimatePresence>
    </div>
  );
};