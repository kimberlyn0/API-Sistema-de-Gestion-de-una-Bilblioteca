import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

export const MensajeNoDisponibles = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center p-8 bg-white rounded-lg shadow-lg"
    >
      <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
      <h3 className="text-xl font-semibold text-gray-800 mb-2">
        ¡Buenas noticias!
      </h3>
      <p className="text-gray-600 text-center">
        Todos los libros están disponibles en este momento.
      </p>
    </motion.div>
  );
};