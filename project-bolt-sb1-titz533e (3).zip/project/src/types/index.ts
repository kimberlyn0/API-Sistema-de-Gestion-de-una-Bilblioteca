export interface Autor {
  nombre: string;
  nacionalidad: string;
}

export interface Comentario {
  id: string;
  texto: string;
  autor: string;
  fecha: string;
}

export interface Libro {
  titulo: string;
  autor: Autor;
  anioPublicacion: number;
  disponibilidad: boolean;
  imagen?: string;
  comentarios?: Comentario[];
}

export type FiltroTipo = 'todos' | 'disponibles' | 'nodisponibles';