// Mapeo de imágenes de libros de Unsplash
export const obtenerImagenLibro = (titulo: string): string => {
  const imagenes = {
    default: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=400',
    'Don Quijote': 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400',
    'Cien años de soledad': 'https://images.unsplash.com/photo-1589998059171-988d887df646?auto=format&fit=crop&q=80&w=400',
    'El Principito': 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400',
  };

  return imagenes[titulo as keyof typeof imagenes] || imagenes.default;
};