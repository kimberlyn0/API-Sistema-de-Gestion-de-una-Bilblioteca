import axios from 'axios';

const BASE_URL = 'https://api-sistema-de-gestion-de-una-bilblioteca.vercel.app/api';

export const obtenerLibros = async () => {
  const response = await axios.get(`${BASE_URL}/libros`);
  return response.data;
};

export const obtenerAutores = async () => {
  const response = await axios.get(`${BASE_URL}/autores`);
  return response.data;
};

export const obtenerLibrosDisponibles = async () => {
  const response = await axios.get(`${BASE_URL}/libros/disponibles`);
  return response.data;
};