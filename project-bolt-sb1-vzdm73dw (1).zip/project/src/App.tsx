import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { BookGrid } from './components/BookGrid';
import { BookModal } from './components/BookModal';
import { Book } from './types';
import { initialBooks } from './data/books';

function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'available'>('all');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  useEffect(() => {
    // Simulamos la carga de datos
    setTimeout(() => {
      setBooks(initialBooks);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         book.autor.nombre.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || (filter === 'available' && book.disponibilidad);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SearchBar
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          filter={filter}
          onFilterChange={setFilter}
        />
        <BookGrid 
          books={filteredBooks} 
          loading={loading} 
          onBookClick={setSelectedBook}
        />
        {selectedBook && (
          <BookModal
            book={selectedBook}
            isOpen={!!selectedBook}
            onClose={() => setSelectedBook(null)}
          />
        )}
      </main>
    </div>
  );
}

export default App;