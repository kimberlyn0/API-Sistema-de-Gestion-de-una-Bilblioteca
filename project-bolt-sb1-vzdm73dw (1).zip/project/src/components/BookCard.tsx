import React from 'react';
import { Book as BookIcon, User } from 'lucide-react';
import { Book } from '../types';

interface BookCardProps {
  book: Book;
  onClick: () => void;
}

export function BookCard({ book, onClick }: BookCardProps) {
  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform transition-transform duration-200 hover:scale-105"
      onClick={onClick}
    >
      <div className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{book.titulo}</h3>
            <div className="mt-2 flex items-center text-sm text-gray-500">
              <User className="h-4 w-4 mr-1" />
              <span>{book.autor.nombre}</span>
            </div>
            <div className="mt-1 text-sm text-gray-500">
              <span>Nacionalidad: {book.autor.nacionalidad}</span>
            </div>
            <div className="mt-1 text-sm text-gray-500">
              <span>Año: {book.anioPublicacion}</span>
            </div>
          </div>
          <BookIcon className="h-6 w-6 text-gray-400" />
        </div>
        <div className="mt-4">
          <span
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              book.disponibilidad
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
            }`}
          >
            {book.disponibilidad ? 'Disponible' : 'No disponible'}
          </span>
        </div>
      </div>
    </div>
  );
}