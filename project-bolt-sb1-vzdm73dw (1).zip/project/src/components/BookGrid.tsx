import React from 'react';
import { Book as BookIcon } from 'lucide-react';
import { Book } from '../types';
import { BookCard } from './BookCard';

interface BookGridProps {
  books: Book[];
  loading: boolean;
  onBookClick: (book: Book) => void;
}

export function BookGrid({ books, loading, onBookClick }: BookGridProps) {
  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Cargando libros...</p>
      </div>
    );
  }

  if (books.length === 0) {
    return (
      <div className="text-center py-12">
        <BookIcon className="h-12 w-12 text-gray-400 mx-auto" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No se encontraron libros</h3>
        <p className="mt-1 text-sm text-gray-500">
          No hay libros que coincidan con tu búsqueda.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {books.map((book, index) => (
        <BookCard 
          key={index} 
          book={book} 
          onClick={() => onBookClick(book)}
        />
      ))}
    </div>
  );
}