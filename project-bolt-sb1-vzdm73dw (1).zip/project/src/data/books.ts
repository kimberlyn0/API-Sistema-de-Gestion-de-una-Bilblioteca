import { Book } from '../types';

export const initialBooks: Book[] = [
  {
    titulo: "El fuego de la vida",
    autor: {
      nombre: "Juan Bosch",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 1965,
    disponibilidad: true
  },
  {
    titulo: "Poesías",
    autor: {
      nombre: "Salomé Ureña",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 1885,
    disponibilidad: true
  },
  {
    titulo: "Cuentos de la selva",
    autor: {
      nombre: "Manuel del Cabral",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 1940,
    disponibilidad: true
  },
  {
    titulo: "La muerte de un perro",
    autor: {
      nombre: "Pedro Mir",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 1955,
    disponibilidad: true
  },
  {
    titulo: "Cuentos completos",
    autor: {
      nombre: "Frank Báez",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 2015,
    disponibilidad: true
  },
  {
    titulo: "El corazón de la tierra",
    autor: {
      nombre: "Nydia Lamarque",
      nacionalidad: "Dominicana"
    },
    anioPublicacion: 2014,
    disponibilidad: true
  }
];