export interface Author {
  nombre: string;
  nacionalidad: string;
}

export interface Book {
  titulo: string;
  autor: Author;
  anioPublicacion: number;
  disponibilidad: boolean;
}